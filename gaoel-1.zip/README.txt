
Licenses :
https://creativemarket.com/licenses

------------------------------------------------

Gaoel Font

Soft, Bold, and Elegant. Gaoel is the new all caps typeface that feels somehow familiar. It inherited an honest tone that’s confident but not arrogant, cozy but not mellow, smooth but not wobbly. The result is a hybrid combining humanistic proportions with a somewhat geometric appearance. This is perfect to sweeten up your headlines, branding visual identity, editorial, poster, and etc.


Thanks for purchasing and I hope you have fun with Gaoel!

~ Hindia


------------------------------------------------

Support

Mail support : hindia.studio@gmail.com / tulusdriyo@gmail.com
Facebook : https://www.facebook.com/hindiastudio
Dribbble : dribbble.com/hindiastudio / dribbble.com/tulusdriyo

